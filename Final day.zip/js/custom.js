// Shreeraj Script Code
$(document).ready(function () {
    preloaderFadeOutTime = 100;
    window.localStorage.removeItem("courses");
    function hidePreloader() {
        var preloader = $(".spinner-wrapper");
        preloader.show().fadeOut(preloaderFadeOutTime);
    }

    setTimeout(() => {
        hidePreloader();
    }, 5000);

    $("#name").focusout(() => {
        var name = $("#name").val();
        var re = /^[A-Za-z ]+$/;
        if (name.length < 3) {
            ///s$("#name-wrapper").removeClass("field-wrapper");
            $(".field-wrapper input").css(
                "border",
                "1px solid #e40707 !important"
            );
            $("#error-name").show();
        } else if (!re.test(name)) {
            $("#error-name").show();
            $("#name").css("border", "1px solid #e40707 !important");
        } else {
            $("#error-name").hide();
        }
    });

    $("#phone").focusout(function () {
        var phone = $("#phone").val();
        if (phone.length != 10) {
            $("#error-phone").show();
        } else {
            $("#error-phone").hide();
        }
    });
    $(document).on("click", function (event) {
        //console.log(event);
        if (event.target.id != "drop") {
            // Hide the menus.
            if (event.target.className != "select") {
                $("#checkboxes").addClass("hide");
            } else {
                var temp = window.localStorage.getItem("courses");
                document.getElementById("error-course").style.display = "none";
                if (temp == null) {
                    window.localStorage.setItem(
                        "courses",
                        event.target.defaultValue
                    );
                    $("#option").html(event.target.defaultValue);
                } else {
                    let str = temp + "," + event.target.defaultValue;
                    window.localStorage.setItem("courses", str);
                    $("#option").html(str);
                }
                //defaultValue;
                console.log(event);
            }
        } else {
            $("#checkboxes").removeClass("hide");
        }
    });
    // $(".select").on("click", function (event) {
    //     console.log(event);
    // });
    const mq = window.matchMedia("(max-width: 767px)");

    if (mq.matches) {
        $("#fixed-button-right").addClass("hide-in-mobile");
        $(".hide-this-element").addClass("hide-in-mobile");
    } else {
        $("#fixed-button-right").removeClass("hide-in-mobile");
        $(".hide-this-element").removeClass("hide-in-mobile");
    }

    // Homepage slider script
    $(".Modern-Slider").slick({
        autoplay: true,
        autoplaySpeed: 4000,
        speed: 600,
        slidesToShow: 1,
        slidesToScroll: 1,
        pauseOnHover: false,
        dots: false,
        pauseOnDotsHover: false,
        cssEase: "linear",
        fade: true,
        draggable: false,
        prevArrow: '<button class="PrevArrow"></button>',
        nextArrow: '<button class="NextArrow"></button>',
    });

    // NewsFeed Script
    jQuery.fn.liScroll = function (settings) {
        settings = jQuery.extend(
            {
                travelocity: 0.03,
            },
            settings
        );
        return this.each(function () {
            var $strip = jQuery(this);
            $strip.addClass("newsticker");
            var stripHeight = 1;
            $strip.find("li").each(function (i) {
                stripHeight += jQuery(this, i).outerHeight(true); // thanks to Michael Haszprunar and Fabien Volpi
            });
            var $mask = $strip.wrap("<div class='mask'></div>");
            var $tickercontainer = $strip
                .parent()
                .wrap("<div class='tickercontainer'></div>");
            var containerHeight = $strip.parent().parent().height(); //a.k.a. 'mask' width
            $strip.height(stripHeight);
            var totalTravel = stripHeight;
            var defTiming = totalTravel / settings.travelocity; // thanks to Scott Waye
            function scrollnews(spazio, tempo) {
                $strip.animate(
                    {
                        top: "-=" + spazio,
                    },
                    tempo,
                    "linear",
                    function () {
                        $strip.css("top", containerHeight);
                        scrollnews(totalTravel, defTiming);
                    }
                );
            }
            scrollnews(totalTravel, defTiming);
            $strip.hover(
                function () {
                    jQuery(this).stop();
                },
                function () {
                    var offset = jQuery(this).offset();
                    var residualSpace = offset.top + stripHeight;
                    var residualTime = residualSpace / settings.travelocity;
                    scrollnews(residualSpace, residualTime);
                }
            );
        });
    };

    $(function () {
        $("ul#ticker01").liScroll();
        $("ul#ticker02").liScroll();
    });

    $("#apply_now").click(function () {
        $("#exampleModal").modal("toggle");
    });

    // $("#inquire_now").click(function () {
    //     $("#exampleModal").modal("toggle");
    // });

    $("#contact_us_now").click(function () {
        $("#exampleModal").modal("toggle");
    });

    $("#contact_us").click(function () {
        $("#exampleModal").modal("toggle");
    });
});

var previous = 0;

function demo(i) {
    if (previous != i) {
        var value = "desc" + previous;
        var tmp = (document.getElementById(value).style.display = "none");
        var value1 = "desc" + i;
        var tmp1 = (document.getElementById(value1).style.display = "block");

        var sel = document.getElementById("select" + i);
        sel.classList.add("selected");
        var sel1 = document.getElementById("select" + previous);
        sel1.classList.remove("selected");
        previous = i;
    }
}

var course_pointer = 0;

function semester(j) {
    if (course_pointer != j) {
        var value = "subject" + course_pointer;
        var tmp = (document.getElementById(value).style.display = "none");
        var value1 = "subject" + j;
        var tmp1 = (document.getElementById(value1).style.display = "block");

        var sel = document.getElementById("select" + j);
        sel.classList.add("selected");
        var sel1 = document.getElementById("select" + course_pointer);
        sel1.classList.remove("selected");
        course_pointer = j;
    }
}

function semester_tab1(tabi,tab_total) {
    for(pointer_i=0;pointer_i<=tab_total;pointer_i++)
    {
        var value1 = "semester_tab1_subject" + pointer_i;
        document.getElementById(value1).style.display = "none";

        var remove_selection = document.getElementById("semester_tab1_" + pointer_i);
        remove_selection.classList.remove("selected");
    }
    var value = "semester_tab1_subject" + tabi;
    var block = (document.getElementById(value).style.display = "block");

    var select = document.getElementById("semester_tab1_" + tabi);
    select.classList.add("selected");
}

function semester_tab2(tabi,tab_total) {
    for(pointer_i=0;pointer_i<=tab_total;pointer_i++)
    {
        var value1 = "semester_tab2_subject" + pointer_i;
        document.getElementById(value1).style.display = "none";

        var remove_selection = document.getElementById("semester_tab2_" + pointer_i);
        remove_selection.classList.remove("selected");
    }
    var value = "semester_tab2_subject" + tabi;
    var block = (document.getElementById(value).style.display = "block");

    var select = document.getElementById("semester_tab2_" + tabi);
    select.classList.add("selected");
}

// Ashish Script Code
var swiper = new Swiper(".swiper-container2", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    // autoplay: true,
    parallax: true,
    autoplay: {
        delay: 3000,
        speed: 100,
    },
    autoplayDisableOnInteraction: false,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

var swiper = new Swiper(".swiper-container1", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,

    parallax: true,
    autoplay: {
        delay: 12000,
        speed: 5000,
    },
    // autoplayDisableOnInteraction: false,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

$("#exampleSlider").multislider({
    interval: 4000,
    slideAll: true,
    duration: 1500,
    continuous: true,
});

// var myVar;
// var isshow = localStorage.getItem("isshow");
// if (isshow == null || isshow == "") {
//     myVar = setTimeout(alertFunc, 30000);

//     function alertFunc() {
//         $("#exampleModal").modal("toggle");
//         localStorage.setItem("isshow", 1);
//     }
// }

// Sulay Code
function showCheckboxes() {
    var expanded = false;

    if (!expanded) {
        $("#checkboxes").addClass("selected-checkboxes");
        expanded = true;
    } else {
        $("#checkboxes").removeClass("selected-checkboxes");
        expanded = false;
    }
}

// Shreeraj Code
function closeIt() {
    $("#checkboxes").removeClass("selected-checkboxes");
}
